const Sequelize = require('sequelize');

const sequelize = new Sequelize("printgcode", "root", "008071", {
    host: 'localhost',
    dialect: 'mysql'
});

sequelize.authenticate()
.then(function(){
    console.log("conexão com banco de dados realizada com sucesso!");
}).catch(function(){
    console.log("erro: conexão com o banco de dados nao realizada com sucesso!");
});

module.exports = sequelize;